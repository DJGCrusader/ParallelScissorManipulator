var classKvaserCAN =
[
    [ "KvaserCAN", "classKvaserCAN.html#a0c4d07c8259bb4a175c0747b27896083", null ],
    [ "KvaserCAN", "classKvaserCAN.html#a5e26a4c6b20b27be0db8a98c59513f56", null ],
    [ "~KvaserCAN", "classKvaserCAN.html#a402aeb15b685ff63acb6963fa96b8e51", null ],
    [ "Close", "classKvaserCAN.html#a500bb48d2dab9b77a2f1f273ec9839b9", null ],
    [ "ConvertError", "classKvaserCAN.html#a46774c2ad32250f1f3578205e045af37", null ],
    [ "Open", "classKvaserCAN.html#a206276bc42bcd39a25dabdb15eb32175", null ],
    [ "RecvFrame", "classKvaserCAN.html#a0243078c3cba1a2fc1f8c510f2213c17", null ],
    [ "SetBaud", "classKvaserCAN.html#a6a01fe45402b21beb54af6281ae30593", null ],
    [ "XmitFrame", "classKvaserCAN.html#a3751ef6bd6d2fbd86f56469152af8567", null ],
    [ "baud", "classKvaserCAN.html#abcfabfc18d031d081cff59a7eb16e3c7", null ],
    [ "Handle_Rd", "classKvaserCAN.html#a01b7cbf0030d9532f5fb05f50668dce2", null ],
    [ "Handle_Wr", "classKvaserCAN.html#abe126413cd09d43d9fbd1a35d02e6126", null ],
    [ "kvBaud", "classKvaserCAN.html#a0bb412754424684b7ef1167d4d099898", null ],
    [ "open", "classKvaserCAN.html#a79892741103741834f229b20718e4f19", null ]
];