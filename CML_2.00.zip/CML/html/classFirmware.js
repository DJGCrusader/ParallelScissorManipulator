var classFirmware =
[
    [ "getAmpType", "classFirmware.html#ae333cda8366195e394bbcefcceb0eced", null ],
    [ "getData", "classFirmware.html#ad11cdf8b7f79f202d51635f732918a5b", null ],
    [ "getFileVersion", "classFirmware.html#a0c7905bd9f5d2c2b793050d17cb1184b", null ],
    [ "getLength", "classFirmware.html#ae96791d07da5d3ebc917ea38441c212d", null ],
    [ "getStart", "classFirmware.html#a7d91503e2532b4158c377809f678193e", null ],
    [ "progress", "classFirmware.html#abe9f3060df47a7bf50c5d2701d52f427", null ]
];