var structAlgoPhaseInit =
[
    [ "AlgoPhaseInit", "structAlgoPhaseInit.html#aabfa21e3a1f53499a81c7491a37d38b0", null ],
    [ "phaseInitConfig", "structAlgoPhaseInit.html#ae95e79c27b6375716e26651bc27736d4", null ],
    [ "phaseInitCurrent", "structAlgoPhaseInit.html#ac85b47b2404ec336db0a1263f8f533db", null ],
    [ "phaseInitTime", "structAlgoPhaseInit.html#a56aec53cc0d00f462a548ac4ca5cd38f", null ]
];