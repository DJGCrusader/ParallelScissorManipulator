var classIxxatCANV3 =
[
    [ "Close", "classIxxatCANV3.html#a500bb48d2dab9b77a2f1f273ec9839b9", null ],
    [ "ConvertError", "classIxxatCANV3.html#a46774c2ad32250f1f3578205e045af37", null ],
    [ "Open", "classIxxatCANV3.html#a206276bc42bcd39a25dabdb15eb32175", null ],
    [ "RecvFrame", "classIxxatCANV3.html#a0243078c3cba1a2fc1f8c510f2213c17", null ],
    [ "SetBaud", "classIxxatCANV3.html#a6a01fe45402b21beb54af6281ae30593", null ],
    [ "XmitFrame", "classIxxatCANV3.html#a3751ef6bd6d2fbd86f56469152af8567", null ],
    [ "baud", "classIxxatCANV3.html#abcfabfc18d031d081cff59a7eb16e3c7", null ],
    [ "channel", "classIxxatCANV3.html#a94e9cfdc116e8607615a5e8529048b1e", null ],
    [ "handle", "classIxxatCANV3.html#a3127ebf018e9da62fa464d348352037d", null ],
    [ "open", "classIxxatCANV3.html#a79892741103741834f229b20718e4f19", null ]
];