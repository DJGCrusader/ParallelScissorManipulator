var structCopleyIODigi =
[
    [ "bankMode", "structCopleyIODigi.html#a4533a2a5bcbc7ed1fbdfeca5b8d5e58e", null ],
    [ "debounce0", "structCopleyIODigi.html#a607812f3dca640ea1f562e9f743dcf1e", null ],
    [ "debounce1", "structCopleyIODigi.html#a95430658f2fe9a2a2a34a03346a535f3", null ],
    [ "debounce2", "structCopleyIODigi.html#a3cc1f137001c3a28eaf25b6ff38e1932", null ],
    [ "debounce3", "structCopleyIODigi.html#afcf7f80d8ea1a48843ed1dabc40959ea", null ],
    [ "debounce4", "structCopleyIODigi.html#a08e2430b5e04b98a40d8be1d08070d17", null ],
    [ "debounce5", "structCopleyIODigi.html#a7e3826f8c3714d62c6f7afb5434efae7", null ],
    [ "debounce6", "structCopleyIODigi.html#a6d26dea59c76776bf839455907d039e8", null ],
    [ "debounce7", "structCopleyIODigi.html#a04b96304a5586ec73c56a3d00438404d", null ],
    [ "faultMsk", "structCopleyIODigi.html#abef22044800b86f63b20f6bde7b304d2", null ],
    [ "hiLoMsk", "structCopleyIODigi.html#a4b77996020f512eb448e0afe974fe77f", null ],
    [ "invMsk", "structCopleyIODigi.html#a9dee619fa36af73d5194b0d8f542931d", null ],
    [ "loHiMsk", "structCopleyIODigi.html#a9aafbf1bcc6e276e6199c06c7dc54a07", null ],
    [ "modeMsk", "structCopleyIODigi.html#a6dae3075f8b3e2db5caeeee93b5e3909", null ],
    [ "pullupMsk", "structCopleyIODigi.html#a511f342f3683bb2ac7ac350f2eb031e2", null ],
    [ "rawMsk", "structCopleyIODigi.html#a8bdb9fd72acc05ffe7c1cd71436369c5", null ],
    [ "typeMsk", "structCopleyIODigi.html#af8c4b784bcb8f6188e5d70f4eabb3ed2", null ],
    [ "valueMsk", "structCopleyIODigi.html#a95758b6635cf1b9b9221882e633fb5f5", null ]
];