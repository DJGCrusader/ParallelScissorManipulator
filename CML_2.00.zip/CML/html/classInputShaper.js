var classInputShaper =
[
    [ "InputShaper", "classInputShaper.html#aa9fbc32fe2ec743dd2e4275098b62827", null ],
    [ "LoadFromCCX", "classInputShaper.html#a28efe112253c464a1fe28b5274462918", null ],
    [ "setInputShapeFilter", "classInputShaper.html#af627f898307293b104ade5818bcb01c0", null ]
];