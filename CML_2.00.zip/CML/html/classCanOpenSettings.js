var classCanOpenSettings =
[
    [ "CanOpenSettings", "classCanOpenSettings.html#ab8549888ed82b4166274f3128d3a97f2", null ],
    [ "readThreadPriority", "classCanOpenSettings.html#a1fd833f4b645760bf6208cd253f0bc0d", null ],
    [ "syncID", "classCanOpenSettings.html#a2ae8d8876a7bf1fe9d59c22f2d46b19e", null ],
    [ "timeID", "classCanOpenSettings.html#ab2cf03ab3fa3d99f9d75986cf3339f8d", null ],
    [ "useAsTimingReference", "classCanOpenSettings.html#aae3e31b1fe3c2e036ec6d38e03ca0fb2", null ]
];