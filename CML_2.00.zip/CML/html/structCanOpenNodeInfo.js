var structCanOpenNodeInfo =
[
    [ "desired", "structCanOpenNodeInfo.html#a960e95aa56b7e5a0dc0130155f4fce1f", null ],
    [ "eventTime", "structCanOpenNodeInfo.html#a6f79de7fbc8d3bad6df69a9e0969e99c", null ],
    [ "guardTimeout", "structCanOpenNodeInfo.html#aaa4b368b229522b91a1af63e8857b4a6", null ],
    [ "guardToggle", "structCanOpenNodeInfo.html#aa0a2408bd6b0e13149d7faa571a0081d", null ],
    [ "guardType", "structCanOpenNodeInfo.html#a59b1bffa74f5a58874f145f15b04beee", null ],
    [ "lifeCounter", "structCanOpenNodeInfo.html#a344db1cfba312ab802859cf66a3d5346", null ],
    [ "lifeTime", "structCanOpenNodeInfo.html#aee0ab386362d070b3456e74951cbdcfb", null ],
    [ "sdoBuff", "structCanOpenNodeInfo.html#afbf8a0c82257ce11c3158da31a9e1401", null ],
    [ "sdoSemPtr", "structCanOpenNodeInfo.html#a0bacae55382b80f49f8e4d5cbcf632a6", null ],
    [ "semPtr", "structCanOpenNodeInfo.html#a36a43a86a5bf9e0a1cbddba14446df74", null ]
];