var classRefObj =
[
    [ "RefObj", "classRefObj.html#a71c752b1e8bba1f72df367856700e246", null ],
    [ "~RefObj", "classRefObj.html#ae6aa80501db7768fa77b45ea7dcca991", null ],
    [ "GrabRef", "classRefObj.html#ac4939d33b0c82477deb8c13dcb61cf37", null ],
    [ "KillRef", "classRefObj.html#ab95870872ab18684a9bae6c145e2cc03", null ],
    [ "setAutoDelete", "classRefObj.html#a6fab9c5cd04fbacb6785bd4afadd88f0", null ],
    [ "SetRefName", "classRefObj.html#abae77dac4851bb13a425973719191330", null ],
    [ "UnlockRef", "classRefObj.html#aa6b0fce58ce8269b241f6d350871a2e5", null ]
];