var structFuncGenConfig =
[
    [ "FuncGenConfig", "structFuncGenConfig.html#a2d808b30ab24c8408edd21e89793878c", null ],
    [ "amp", "structFuncGenConfig.html#a961ffc3986b19803412e4795e9c018ee", null ],
    [ "cfg", "structFuncGenConfig.html#a79256765c80d63186976f1c2680ed76f", null ],
    [ "duty", "structFuncGenConfig.html#a5bc7d225c4a3009d029c5e91953833b5", null ],
    [ "freq", "structFuncGenConfig.html#a8708c75b74813d9c71314252936425f3", null ]
];