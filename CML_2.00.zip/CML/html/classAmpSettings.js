var classAmpSettings =
[
    [ "AmpSettings", "classAmpSettings.html#a92ba18a71fe32fc6d6cb0993e3b8584c", null ],
    [ "enableOnInit", "classAmpSettings.html#aa07869614cca80ac6f08b37bda14d399", null ],
    [ "guardTime", "classAmpSettings.html#a8d9fbd5c1d6609dc9252f0f91ff02f50", null ],
    [ "heartbeatPeriod", "classAmpSettings.html#a737badcdd4a8d6c3429714eee234b6a4", null ],
    [ "heartbeatTimeout", "classAmpSettings.html#a434dbfa90aeb68f0670d5b33300f4989", null ],
    [ "initialMode", "classAmpSettings.html#a2bc78dd30b7d2deae86acb1fe0f60a65", null ],
    [ "lifeFactor", "classAmpSettings.html#a8c6af83a3d3743dd868c6f66f841dc9b", null ],
    [ "maxPvtSendCt", "classAmpSettings.html#a0843ef0d4f8721aa10cd71a739511aa1", null ],
    [ "resetOnInit", "classAmpSettings.html#a27cb91a3a13c1840319732a592e88278", null ],
    [ "synchID", "classAmpSettings.html#aee34589e9824c2d6576217518326922c", null ],
    [ "synchPeriod", "classAmpSettings.html#a664786242cc7e8a0b4047019941f0f2c", null ],
    [ "synchProducer", "classAmpSettings.html#a8bcc492759dbf1201ab3e9839c2566c0", null ],
    [ "synchUseFirstAmp", "classAmpSettings.html#a0b21ff82b90f6da7112b6193eb32b43b", null ],
    [ "timeStampID", "classAmpSettings.html#adb7875d94c7268dd9f54b642266b47d0", null ]
];