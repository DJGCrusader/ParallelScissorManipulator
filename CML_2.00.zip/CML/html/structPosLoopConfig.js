var structPosLoopConfig =
[
    [ "PosLoopConfig", "structPosLoopConfig.html#af2bfc9bf44bf4623f66916b09d13b450", null ],
    [ "kaff", "structPosLoopConfig.html#a11dfc536b562862fe60a60597f3d7876", null ],
    [ "kd", "structPosLoopConfig.html#a3302217a45d5a152fb54e1b1aafb2134", null ],
    [ "ki", "structPosLoopConfig.html#afc0f115aa5e331fcf6962a12c77c365e", null ],
    [ "kiDrain", "structPosLoopConfig.html#a84f55d65d2ac45f3aa12d1e329170f63", null ],
    [ "kp", "structPosLoopConfig.html#a6346c0736b25d1026af8c15f75adb7d7", null ],
    [ "kvff", "structPosLoopConfig.html#a2aba7dce3e57dac955273eae083f13f7", null ],
    [ "scale", "structPosLoopConfig.html#a5f61ab98476fe012c6bfd949c40f9eec", null ],
    [ "xKd", "structPosLoopConfig.html#ae9e22e1651a0257732c781447f889be2", null ],
    [ "xKi", "structPosLoopConfig.html#a9ee875133ef926015bb3ea00b0c77022", null ],
    [ "xKp", "structPosLoopConfig.html#a29dd027062dd59804d9674cf8e744387", null ]
];