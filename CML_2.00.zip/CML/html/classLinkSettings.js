var classLinkSettings =
[
    [ "LinkSettings", "classLinkSettings.html#a245a884e82210b1a65c84bd0d8d929c6", null ],
    [ "haltOnPosWarn", "classLinkSettings.html#a287666a21ae88f2c2e68c31e2b98fc7f", null ],
    [ "haltOnVelWin", "classLinkSettings.html#a0efb2c5414f34f5e212c196fc73996cf", null ],
    [ "moveAckTimeout", "classLinkSettings.html#a3c95500ea6c84b96c078ab1d64deeeff", null ]
];