var structIOModuleSettings =
[
    [ "guardTime", "structIOModuleSettings.html#a8d9fbd5c1d6609dc9252f0f91ff02f50", null ],
    [ "heartbeatPeriod", "structIOModuleSettings.html#a737badcdd4a8d6c3429714eee234b6a4", null ],
    [ "heartbeatTimeout", "structIOModuleSettings.html#a434dbfa90aeb68f0670d5b33300f4989", null ],
    [ "lifeFactor", "structIOModuleSettings.html#a8c6af83a3d3743dd868c6f66f841dc9b", null ],
    [ "useStandardAinPDO", "structIOModuleSettings.html#af8714def5a3de64cefe0324ce6a2f105", null ],
    [ "useStandardAoutPDO", "structIOModuleSettings.html#a0ddc4683c8ed07fc44df341386b6c45d", null ],
    [ "useStandardDinPDO", "structIOModuleSettings.html#a8fdbc5b4bfe3066c6af781928173251c", null ],
    [ "useStandardDoutPDO", "structIOModuleSettings.html#aa98c2c12b5126523fd9500ed5e80221f", null ]
];