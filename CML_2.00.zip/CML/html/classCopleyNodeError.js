var classCopleyNodeError =
[
    [ "CopleyNodeError", "classCopleyNodeError.html#aaa637979b1b0d8c82424e7b73be71041", null ]
];