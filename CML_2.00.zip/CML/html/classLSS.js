var classLSS =
[
    [ "LSS", "classLSS.html#abdfb2a049daeb0418b92046da637be55", null ],
    [ "FindAmplifiers", "classLSS.html#ae79101379f9a6933fe4571a69c7938bd", null ],
    [ "FindAmpSerial", "classLSS.html#a49df7660413a8a7c596e2c098401a680", null ],
    [ "GetAmpNodeID", "classLSS.html#a8276812529e2c02e29f4a9799f995665", null ],
    [ "getTimeout", "classLSS.html#a9c8fea687f1c4b6853a24c720d3c7d75", null ],
    [ "NewFrame", "classLSS.html#ad250e761b353af6cda60f1b61e229c99", null ],
    [ "SelectAmp", "classLSS.html#a3e827f25467f3029d8105d5cee1d696b", null ],
    [ "SetAmpNodeID", "classLSS.html#ad248c41f810042b3bb33b8c7b0fdcde2", null ],
    [ "setTimeout", "classLSS.html#a2df7ba8ac09112a271c96acbb4799b7e", null ],
    [ "Xmit", "classLSS.html#a878500f4ad97b5173fae0d9d36fa33ec", null ]
];