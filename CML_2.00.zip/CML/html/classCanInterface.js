var classCanInterface =
[
    [ "CanInterface", "classCanInterface.html#af6f4b736720fcf1be3aee0734fe2d840", null ],
    [ "CanInterface", "classCanInterface.html#a87f23bbc06791efff4a4c6e594bdd535", null ],
    [ "~CanInterface", "classCanInterface.html#ad9a73e69c9a23144fd2ebd5e771ca314", null ],
    [ "Close", "classCanInterface.html#a7a6218ece98087276b0774b9c434b2b7", null ],
    [ "Open", "classCanInterface.html#a8b0ab47ca76d8fa64b7306212dd1cc4a", null ],
    [ "Recv", "classCanInterface.html#ac831253861b47c306c3127b3864468b3", null ],
    [ "RecvFrame", "classCanInterface.html#a0243078c3cba1a2fc1f8c510f2213c17", null ],
    [ "SetBaud", "classCanInterface.html#aebcbd2d784da05058494175d7256f64a", null ],
    [ "SetName", "classCanInterface.html#a5a5a2b70503dd946c780b91a798fa769", null ],
    [ "SupportsTimestamps", "classCanInterface.html#ad29cca9a04b3fc3c2402e21b5280d007", null ],
    [ "Xmit", "classCanInterface.html#acdf3854c843a8fadde2ef2a6cdf8946c", null ],
    [ "XmitFrame", "classCanInterface.html#a3751ef6bd6d2fbd86f56469152af8567", null ],
    [ "portName", "classCanInterface.html#a0b618d18dae228750be66b361c3fb6e9", null ]
];