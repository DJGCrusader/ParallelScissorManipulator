var CML__Settings_8h =
[
    [ "CML_ALLOW_FLOATING_POINT", "CML__Settings_8h.html#a240808ca0ab0b8e8d245a930f2e83027", null ],
    [ "CML_DEBUG_ASSERT", "CML__Settings_8h.html#a0593968cfc9a29c3f3835b1ffd80ec54", null ],
    [ "CML_ENABLE_IOMODULE_PDOS", "CML__Settings_8h.html#a246eb48a374ed6fdade308bcf4c89d40", null ],
    [ "CML_ENABLE_USER_UNITS", "CML__Settings_8h.html#a013ea65f1ef377c7d8ace0599a61aaf6", null ],
    [ "CML_ERROR_HASH_SIZE", "CML__Settings_8h.html#adcb0166903df33334a3583eae186b780", null ],
    [ "CML_ERROR_MESSAGES", "CML__Settings_8h.html#add8b5084ffde8d8d9d4a7ddfc4085988", null ],
    [ "CML_FILE_ACCESS_OK", "CML__Settings_8h.html#aef520c44a7be7b12a28e2d9abd63d065", null ],
    [ "CML_HASH_SIZE", "CML__Settings_8h.html#acbd3b34de6e37aefe256e3cbd3c7f7fe", null ],
    [ "CML_LINKAGE_TRJ_BUFFER_SIZE", "CML__Settings_8h.html#a5eab0d70640a03b283671595155ebbd9", null ],
    [ "CML_MAX_AMPS_PER_LINK", "CML__Settings_8h.html#a520d30af20b4029b5de3adb412720968", null ],
    [ "CML_MAX_ECAT_FRAMES", "CML__Settings_8h.html#a27819d64d7426d7d3b2dab6453fd7d48", null ],
    [ "CML_NAMESPACE", "CML__Settings_8h.html#aa9368535fbf405a8bbb75f5c8b3fa0ef", null ],
    [ "CML_NAMESPACE_START", "CML__Settings_8h.html#a75224982c3d4b74eefa204bcfafb7442", null ]
];