var structProfileConfigTrap =
[
    [ "ProfileConfigTrap", "structProfileConfigTrap.html#a4b0f454e70f21d1c466f30d230c3da87", null ],
    [ "acc", "structProfileConfigTrap.html#a3adc3eb4079d6939e35e28b491e82e9a", null ],
    [ "dec", "structProfileConfigTrap.html#ab47dbdb375fca9641a4fbd2aa4860ba0", null ],
    [ "pos", "structProfileConfigTrap.html#a83206d8cdda5538b62a2d5719d22c2e9", null ],
    [ "vel", "structProfileConfigTrap.html#aa19b3ea8ea93bdc06b6bfb045689b3e2", null ]
];