var classPvtSegCache =
[
    [ "PvtSegCache", "classPvtSegCache.html#a061135a5b7d1a99db87d24093d77cb32", null ],
    [ "AddSegment", "classPvtSegCache.html#a0de958e66ef79973d21d8d55bb3a3e99", null ],
    [ "Clear", "classPvtSegCache.html#aa71d36872f416feaa853788a7a7a7ef8", null ],
    [ "GetPosition", "classPvtSegCache.html#ad2abe23b2b0df400d5fb5deaa56645bd", null ],
    [ "GetSegment", "classPvtSegCache.html#a29a90fd640c9ee90c2b5cf0f64c8efb1", null ]
];