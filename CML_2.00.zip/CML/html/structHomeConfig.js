var structHomeConfig =
[
    [ "HomeConfig", "structHomeConfig.html#a409f26715f80d8291abe6ae629a40fa7", null ],
    [ "accel", "structHomeConfig.html#acdc17fa919c1daff2d832afc759736ca", null ],
    [ "current", "structHomeConfig.html#a8cbce66df5b160976de94cbb2c25960c", null ],
    [ "delay", "structHomeConfig.html#a873a308df1a59781ae1b5f960aab1bac", null ],
    [ "extended", "structHomeConfig.html#aa2425d32b138155a043ce7eeb276b437", null ],
    [ "method", "structHomeConfig.html#a04e37757e3aba2a9e5951bf77337f855", null ],
    [ "offset", "structHomeConfig.html#a6bbe9824e5268a277ddde5d76460a691", null ],
    [ "velFast", "structHomeConfig.html#aca81531082926fa8382d567a2ea1e825", null ],
    [ "velSlow", "structHomeConfig.html#a63da93c8fc678c3beed63c14b5c97da7", null ]
];