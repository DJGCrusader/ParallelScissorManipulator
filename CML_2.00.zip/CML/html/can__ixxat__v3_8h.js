var can__ixxat__v3_8h =
[
    [ "IxxatCANV3", "classIxxatCANV3.html", "classIxxatCANV3" ],
    [ "IXXAT_RX_QUEUE_SZ", "can__ixxat__v3_8h.html#a3b596936b30c568c4572549ebf781c1c", null ]
];