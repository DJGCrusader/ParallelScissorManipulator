var structCanFrame =
[
    [ "data", "structCanFrame.html#ab398309652c4a6bbd519395303e2e588", null ],
    [ "id", "structCanFrame.html#a51be18c1422c1f14d31c199caf6642e6", null ],
    [ "length", "structCanFrame.html#aacdf6aeb87f8e0c92d0773f86e14adfc", null ],
    [ "timestamp", "structCanFrame.html#a88ecc2ef3cf2a76fdfec6e779735ec0a", null ],
    [ "type", "structCanFrame.html#a1a22277b4fc82adbc0c28a64c9e95ecc", null ]
];