var structCopleyIOAnlg =
[
    [ "iAbsDelta", "structCopleyIOAnlg.html#a828f5e6ea5da5b6f01ce90e2c92da7b9", null ],
    [ "iFactor", "structCopleyIOAnlg.html#ac5ee9e04bef21821508766e665d00c15", null ],
    [ "iFlags", "structCopleyIOAnlg.html#a988bcfb34de13d5af8e51d37d620bd7a", null ],
    [ "iLoLimit", "structCopleyIOAnlg.html#a6903f95d0bc2a98187a46ef42bcb538d", null ],
    [ "iMask", "structCopleyIOAnlg.html#a3d5c7872b265fda2664563c5677ae4db", null ],
    [ "iNegDelta", "structCopleyIOAnlg.html#a273cd9d77d54bfb8ab27b824d574e711", null ],
    [ "iOffset", "structCopleyIOAnlg.html#aca8d5eb1b1cd47924559157133c6ed59", null ],
    [ "iPosDelta", "structCopleyIOAnlg.html#aeb2ce3255f16edcca245595b6c20eb4b", null ],
    [ "iRaw", "structCopleyIOAnlg.html#af29056ab46bee83cfb00ff439a1edf68", null ],
    [ "iScaled", "structCopleyIOAnlg.html#a44b2b709c687d2030ec286eb134f93ad", null ],
    [ "iUpLimit", "structCopleyIOAnlg.html#a1156cf5d5673269c7c280bb001be360d", null ]
];