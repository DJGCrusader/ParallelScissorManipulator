var structCopleyIOCfg =
[
    [ "anlg", "structCopleyIOCfg.html#ad3092a8d033535b68fbd4bacbf1b3abe", null ],
    [ "digi", "structCopleyIOCfg.html#ac922d60b1c8b558b61cefa2d314c2e47", null ],
    [ "info", "structCopleyIOCfg.html#a28062e79ed3ce797c3e3def7432dfe6b", null ],
    [ "pwm", "structCopleyIOCfg.html#ada796bbc3b3d25760d8ac2a96b1294fc", null ]
];