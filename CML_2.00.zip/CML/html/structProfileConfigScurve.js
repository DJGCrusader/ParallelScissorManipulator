var structProfileConfigScurve =
[
    [ "ProfileConfigScurve", "structProfileConfigScurve.html#a4fe530b17f8fc852311b9ed8ac3da617", null ],
    [ "acc", "structProfileConfigScurve.html#a3adc3eb4079d6939e35e28b491e82e9a", null ],
    [ "jrk", "structProfileConfigScurve.html#a75412786b699b3af85b1b5c990dc54d0", null ],
    [ "pos", "structProfileConfigScurve.html#a83206d8cdda5538b62a2d5719d22c2e9", null ],
    [ "vel", "structProfileConfigScurve.html#aa19b3ea8ea93bdc06b6bfb045689b3e2", null ]
];