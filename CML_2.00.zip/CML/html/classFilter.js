var classFilter =
[
    [ "Filter", "classFilter.html#add9c079e90b08a0075e5430dc02cb397", null ],
    [ "getFloatCoef", "classFilter.html#a47160b2aedfd49786b856e80dbdbad28", null ],
    [ "getIntCoef", "classFilter.html#a0f93a26b728565e83493c168d1c39f66", null ],
    [ "LoadFromCCX", "classFilter.html#a88d7c81e2db5723db2cdaa716164d709", null ]
];