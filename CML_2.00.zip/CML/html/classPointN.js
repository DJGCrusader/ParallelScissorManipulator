var classPointN =
[
    [ "~PointN", "classPointN.html#a453e1de915f438307b4628dd8a35d5b1", null ],
    [ "getDim", "classPointN.html#a84c92cae02026b8c6217b77f1798398a", null ],
    [ "getMax", "classPointN.html#a661af520e91cdd8a2609f3112fab5e1a", null ],
    [ "setDim", "classPointN.html#a9d60f3790cca2b7da37308a300212111", null ]
];