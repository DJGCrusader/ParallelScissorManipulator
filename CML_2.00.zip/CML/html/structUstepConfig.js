var structUstepConfig =
[
    [ "UstepConfig", "structUstepConfig.html#a100070128b8fcecc870c482e9f1dc1fc", null ],
    [ "detentCorrectionGain", "structUstepConfig.html#a8a9d799d8a32e9e6bba5218cea41c3d8", null ],
    [ "maxVelAdj", "structUstepConfig.html#ae0b8d93784e7ffcf8dc83ed94de96b47", null ],
    [ "ustepConfigAndStatus", "structUstepConfig.html#a9c1b07bf081bb12924bf956e95fb5a22", null ],
    [ "ustepPGainOutLoop", "structUstepConfig.html#af1f145f08adb661797a2669d959c9057", null ]
];