var classPDO__Error =
[
    [ "PDO_Error", "classPDO__Error.html#a9924cc10ae8a110ead9a0de2b11ff596", null ]
];