var classRefObjLocker =
[
    [ "RefObjLocker", "classRefObjLocker.html#a54a5259878080eebe74ad2f510bd25fe", null ],
    [ "~RefObjLocker", "classRefObjLocker.html#af6ef154bbfd99421d622b1221225a652", null ],
    [ "operator*", "classRefObjLocker.html#adf3a47f4b2ae453f66634bb41e82b7a0", null ],
    [ "operator->", "classRefObjLocker.html#afa61b68f31d21dda8266edcfd3a13471", null ]
];