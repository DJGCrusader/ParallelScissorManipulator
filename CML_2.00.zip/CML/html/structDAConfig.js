var structDAConfig =
[
    [ "DAConfig", "structDAConfig.html#a01ce027a988ef4c15985979d07313c8b", null ],
    [ "daConverterConfig", "structDAConfig.html#a4c31a718588de03cfa039f622fba638f", null ]
];