var classEventNone =
[
    [ "EventNone", "classEventNone.html#a64dd1a556f8195869f37a601b98f7eaf", null ],
    [ "EventNone", "classEventNone.html#a67f707372728ead002f1ec4abd78d72f", null ],
    [ "isTrue", "classEventNone.html#a3f188ac25964484e41895b10feec7acd", null ]
];