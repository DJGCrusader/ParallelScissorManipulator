var structVelLoopConfig =
[
    [ "VelLoopConfig", "structVelLoopConfig.html#a2e78d80e37dcceaaa223a0d4ed437f22", null ],
    [ "estopDec", "structVelLoopConfig.html#a2d332fa4f18c85c97061d6981a1a72b1", null ],
    [ "kaff", "structVelLoopConfig.html#a11dfc536b562862fe60a60597f3d7876", null ],
    [ "ki", "structVelLoopConfig.html#afc0f115aa5e331fcf6962a12c77c365e", null ],
    [ "kp", "structVelLoopConfig.html#a6346c0736b25d1026af8c15f75adb7d7", null ],
    [ "maxAcc", "structVelLoopConfig.html#ac5c412e7a9fd1428032cdc749ce3f5ee", null ],
    [ "maxDec", "structVelLoopConfig.html#a4a77f9d6123ae55cccc517b5de3d1867", null ],
    [ "maxVel", "structVelLoopConfig.html#a6961bf434913b727429928f3d13e4616", null ],
    [ "shift", "structVelLoopConfig.html#aceb6e64f8f02e264ae6a6b87f8efcc2a", null ],
    [ "velCmdff", "structVelLoopConfig.html#a8aff9600a4974d7e83f9a2581d3a1c10", null ],
    [ "viDrain", "structVelLoopConfig.html#aeae5604ff9292a33010215d53e15b42a", null ]
];