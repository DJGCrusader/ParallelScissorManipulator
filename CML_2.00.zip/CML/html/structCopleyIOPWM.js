var structCopleyIOPWM =
[
    [ "oFactor", "structCopleyIOPWM.html#a1b788679255dffcbebc38feb8ee91727", null ],
    [ "oOffset", "structCopleyIOPWM.html#a287920ca1c6ae6554b58670563b55f70", null ],
    [ "oRaw", "structCopleyIOPWM.html#aa7818366ba2e114ce04d8d0a8404980d", null ],
    [ "oScaled", "structCopleyIOPWM.html#a110a6b3be5af5f652cb8d1aa0d64e15f", null ]
];