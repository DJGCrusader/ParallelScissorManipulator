var structTrackingWindows =
[
    [ "TrackingWindows", "structTrackingWindows.html#a13da66e59e95fc89eeafa92bfef2dfe7", null ],
    [ "settlingTime", "structTrackingWindows.html#a82fb642a66695ada47c7063f076b4dfe", null ],
    [ "settlingWin", "structTrackingWindows.html#ac71c2960c2d197863e1df0bf155c0ecc", null ],
    [ "trackErr", "structTrackingWindows.html#af98a908f1be17c7d2ec213402eeeb557", null ],
    [ "trackWarn", "structTrackingWindows.html#aa4f8961e348a4f59175907f8ac519050", null ],
    [ "velWarnTime", "structTrackingWindows.html#aa90bc684e89d7aa6ce856493c6021f3d", null ],
    [ "velWarnWin", "structTrackingWindows.html#a9188363a6197baedd7f1425a8335cd0a", null ]
];