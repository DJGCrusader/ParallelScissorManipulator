var structAmpIoCfg =
[
    [ "AmpIoCfg", "structAmpIoCfg.html#a0eca6e88574da495b0ad0f7204446759", null ],
    [ "inCfg", "structAmpIoCfg.html#a57efe7e4280a098c6115be8398164a10", null ],
    [ "inDebounce", "structAmpIoCfg.html#a63ee4122228e666f1590ab830321b99d", null ],
    [ "inPullUpCfg", "structAmpIoCfg.html#a3fd1be0ac215ee6964909bfc000ea85a", null ],
    [ "inPullUpCfg32", "structAmpIoCfg.html#aa85e7b590a26561211abc893e7b6b07b", null ],
    [ "inputCt", "structAmpIoCfg.html#aee45da1e43bfe87d983febd4dcec42df", null ],
    [ "ioOptions", "structAmpIoCfg.html#a592b6b72493bee8c1e33b11854639bd9", null ],
    [ "outCfg", "structAmpIoCfg.html#a3b7daddc8a4e5adbea0007458fc5fd8d", null ],
    [ "outMask", "structAmpIoCfg.html#ada0a8bd12c8a1a1b9dfd19d304af92af", null ],
    [ "outMask1", "structAmpIoCfg.html#a1cbb558770762bf00e6a716353a57d81", null ],
    [ "outputCt", "structAmpIoCfg.html#a9869341b36135b99964d9d0c1d6ecb0f", null ]
];