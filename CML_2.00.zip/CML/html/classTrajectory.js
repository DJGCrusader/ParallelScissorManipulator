var classTrajectory =
[
    [ "~Trajectory", "classTrajectory.html#ab987e6d84bde821d7e3c212c48b99ce7", null ],
    [ "Finish", "classTrajectory.html#a6ea398427e4775e65b49a00b467a6e47", null ],
    [ "MaximumBufferPointsToUse", "classTrajectory.html#a9938bb134c5f7a368af7fad11f953fbe", null ],
    [ "NextSegment", "classTrajectory.html#a803d2ddcf40496c87137c1e822066d22", null ],
    [ "StartNew", "classTrajectory.html#abcc531eb8cb2d5b9446c9acd5271c02d", null ],
    [ "UseVelocityInfo", "classTrajectory.html#a9481cca28098bd947aae860dacca876d", null ]
];