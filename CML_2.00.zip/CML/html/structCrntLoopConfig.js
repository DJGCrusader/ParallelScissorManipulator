var structCrntLoopConfig =
[
    [ "CrntLoopConfig", "structCrntLoopConfig.html#af0329ae9cd1d65330362d8c3f6a69390", null ],
    [ "contLim", "structCrntLoopConfig.html#a3b01cf9d4211d57bbee1e759f75b965e", null ],
    [ "ki", "structCrntLoopConfig.html#afc0f115aa5e331fcf6962a12c77c365e", null ],
    [ "kp", "structCrntLoopConfig.html#a6346c0736b25d1026af8c15f75adb7d7", null ],
    [ "offset", "structCrntLoopConfig.html#afedb1b417e0acd2200a0e63a477ecb7a", null ],
    [ "peakLim", "structCrntLoopConfig.html#a5db15b146039ea402e2c4e763016a67a", null ],
    [ "peakTime", "structCrntLoopConfig.html#a3adf860fe9910fa8b22b04ee920485d8", null ],
    [ "slope", "structCrntLoopConfig.html#aaf2be9b51412bd0f3e28b716aa381564", null ],
    [ "stepHoldCurrent", "structCrntLoopConfig.html#ace66c46938233aa03bde1d81a0541960", null ],
    [ "stepRun2HoldTime", "structCrntLoopConfig.html#a6bff1492df506a8fc4ff7ab88861a60c", null ],
    [ "stepVolControlDelayTime", "structCrntLoopConfig.html#a5405e3442d5a32166af9b19d97b9baee", null ]
];