var structPwmInConfig =
[
    [ "PwmInConfig", "structPwmInConfig.html#a24e1aad6abe5614c9d4eb44c882c4ce5", null ],
    [ "cfg", "structPwmInConfig.html#a79256765c80d63186976f1c2680ed76f", null ],
    [ "freq", "structPwmInConfig.html#a8708c75b74813d9c71314252936425f3", null ],
    [ "scale", "structPwmInConfig.html#afed7c61f24e1cbeab9984fa82008cd56", null ],
    [ "uvCfg", "structPwmInConfig.html#a763086de434cad4d8c197ca6403eb3dd", null ]
];