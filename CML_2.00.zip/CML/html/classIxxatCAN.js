var classIxxatCAN =
[
    [ "IxxatCAN", "classIxxatCAN.html#ab7d83a344275b521185006caa0043034", null ],
    [ "IxxatCAN", "classIxxatCAN.html#aa2cd0f810f8ad55d3b11df1338f73309", null ],
    [ "~IxxatCAN", "classIxxatCAN.html#ab4d27c4e04d2204f8cacc0cdf946a1e6", null ],
    [ "Close", "classIxxatCAN.html#a500bb48d2dab9b77a2f1f273ec9839b9", null ],
    [ "ConvertError", "classIxxatCAN.html#a46774c2ad32250f1f3578205e045af37", null ],
    [ "Open", "classIxxatCAN.html#a206276bc42bcd39a25dabdb15eb32175", null ],
    [ "RecvFrame", "classIxxatCAN.html#a0243078c3cba1a2fc1f8c510f2213c17", null ],
    [ "rxInt", "classIxxatCAN.html#a1c7d5d059988bddc606d4f439b12ebb0", null ],
    [ "SetBaud", "classIxxatCAN.html#a6a01fe45402b21beb54af6281ae30593", null ],
    [ "XmitFrame", "classIxxatCAN.html#a3751ef6bd6d2fbd86f56469152af8567", null ],
    [ "baud", "classIxxatCAN.html#abcfabfc18d031d081cff59a7eb16e3c7", null ],
    [ "channel", "classIxxatCAN.html#a94e9cfdc116e8607615a5e8529048b1e", null ],
    [ "handle", "classIxxatCAN.html#a3127ebf018e9da62fa464d348352037d", null ],
    [ "open", "classIxxatCAN.html#a79892741103741834f229b20718e4f19", null ]
];