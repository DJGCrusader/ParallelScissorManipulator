var structCopleyIOInfo =
[
    [ "anlgInt", "structCopleyIOInfo.html#a4d7eb6d9189d1667cda71ac02551cdcc", null ],
    [ "anlgIntEna", "structCopleyIOInfo.html#a2d4db49cc7428cfc3956298a365c9838", null ],
    [ "baud", "structCopleyIOInfo.html#a6ecb915b8993f66d3cf0f7ca315c635e", null ],
    [ "digiIntEna", "structCopleyIOInfo.html#aee96035a117793efceeb654394cd9484", null ],
    [ "fwVersion", "structCopleyIOInfo.html#a6c9166d1b5ab1edbace23cc48ef545b8", null ],
    [ "hostCfg", "structCopleyIOInfo.html#a44004c3b09f1753732696da05d5b17bf", null ],
    [ "hwType", "structCopleyIOInfo.html#afaf31a968a09eba487ea8e15fbc4430c", null ],
    [ "loopRate", "structCopleyIOInfo.html#a87d91acb3f370d7b54a5f09c128392c9", null ],
    [ "maxWords", "structCopleyIOInfo.html#a920c445458eb5ed2d4f5fb4644b5c527", null ],
    [ "mfgInfo", "structCopleyIOInfo.html#a422caf1d801b8431569bbcb3323a09fb", null ],
    [ "model", "structCopleyIOInfo.html#a1efea6802a465d76d5e1e0088be2acc0", null ],
    [ "name", "structCopleyIOInfo.html#aa226406d8650ec99588237a9ff1c29a8", null ],
    [ "nodeCfg", "structCopleyIOInfo.html#a43347169d752170d1ff1075c6d410fc9", null ],
    [ "nodeID", "structCopleyIOInfo.html#aaa308baf18271cd259705d5eae81b62c", null ],
    [ "pwmPeriodA", "structCopleyIOInfo.html#afee302bf8d07a724f798b72aa65c132f", null ],
    [ "pwmPeriodB", "structCopleyIOInfo.html#a47fb10cace7a24f0ac709506bce3edfe", null ],
    [ "rate", "structCopleyIOInfo.html#aba3d9f687f3a909aefa4b490f7e29b8f", null ],
    [ "rateCfg", "structCopleyIOInfo.html#ab4ca04b9f32be72e9219c8b0034c0249", null ],
    [ "serial", "structCopleyIOInfo.html#af56a06cae964c0d87bf433740868c0fb", null ],
    [ "status", "structCopleyIOInfo.html#a1b1f8859ac708adf089c8af955aab94b", null ]
];