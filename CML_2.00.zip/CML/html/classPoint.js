var classPoint =
[
    [ "getDim", "classPoint.html#afab5a8302daf68070432988308cdbcc3", null ],
    [ "getMax", "classPoint.html#a6297b9822c719750d86aa6385e98da12", null ],
    [ "setDim", "classPoint.html#aa79211cc31d8baa77591fb5fff7bf883", null ]
];