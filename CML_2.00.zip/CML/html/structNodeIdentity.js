var structNodeIdentity =
[
    [ "productCode", "structNodeIdentity.html#a49cb4e0a1a9a74ae9ff712fde9761229", null ],
    [ "revision", "structNodeIdentity.html#aac20f996e9fc883068fc42d96a7d43e5", null ],
    [ "serial", "structNodeIdentity.html#af56a06cae964c0d87bf433740868c0fb", null ],
    [ "vendorID", "structNodeIdentity.html#a118431596a50ea50c333aae5cd5f0eec", null ]
];