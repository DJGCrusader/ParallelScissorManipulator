var structProfileConfigVel =
[
    [ "ProfileConfigVel", "structProfileConfigVel.html#ab478e84b5ae0f60b827ae7a7a2e8f595", null ],
    [ "acc", "structProfileConfigVel.html#a3adc3eb4079d6939e35e28b491e82e9a", null ],
    [ "dec", "structProfileConfigVel.html#ab47dbdb375fca9641a4fbd2aa4860ba0", null ],
    [ "dir", "structProfileConfigVel.html#aaffd503630bf9f08a129296435360920", null ],
    [ "vel", "structProfileConfigVel.html#aa19b3ea8ea93bdc06b6bfb045689b3e2", null ]
];