var classCopleyMotionLibrary =
[
    [ "CopleyMotionLibrary", "classCopleyMotionLibrary.html#a766af4e05a92d464177c7285c51858db", null ],
    [ "~CopleyMotionLibrary", "classCopleyMotionLibrary.html#a9e9a21c5f0caa096167d77722aeba133", null ],
    [ "Debug", "classCopleyMotionLibrary.html#a4350ac25d9ac3e66ff9c1f9f4063d9ce", null ],
    [ "Error", "classCopleyMotionLibrary.html#a01f9573b30587e671a962985420c3fb3", null ],
    [ "FlushLog", "classCopleyMotionLibrary.html#a7072922c2e42ea605534f83810c24236", null ],
    [ "GetDebugLevel", "classCopleyMotionLibrary.html#a307bcf49ac5b9e668c91b360b6a6c747", null ],
    [ "GetFlushLog", "classCopleyMotionLibrary.html#ad4ac097d6b8d7fe965223669526250f9", null ],
    [ "GetLogFile", "classCopleyMotionLibrary.html#a45202d17b60c2390ff0ea64bd73fa992", null ],
    [ "GetMaxLogSize", "classCopleyMotionLibrary.html#ac320e648d80135638073bee19ec06db3", null ],
    [ "GetVersionString", "classCopleyMotionLibrary.html#aa48207779bd3f2604de882379898b1ce", null ],
    [ "LogCAN", "classCopleyMotionLibrary.html#a6d0a842d171aa664a0652ac7b0102a82", null ],
    [ "SetDebugLevel", "classCopleyMotionLibrary.html#a607793b153f2d83d21b15ee9098ce887", null ],
    [ "SetFlushLog", "classCopleyMotionLibrary.html#a79b9ea6a96730fbc31ce1f6ca4523407", null ],
    [ "SetLogFile", "classCopleyMotionLibrary.html#aa5510426614ba2f51bc831ede3bfe299", null ],
    [ "SetMaxLogSize", "classCopleyMotionLibrary.html#a2baa22c092b048336f5c9ef6801b1c18", null ],
    [ "Warn", "classCopleyMotionLibrary.html#af8b5cc82a8657d50c0141b7c7fbf76c9", null ]
];