var classEtherCatSettings =
[
    [ "EtherCatSettings", "classEtherCatSettings.html#afa0ca69694cb1afeb6be4f9b1eb3d04a", null ],
    [ "cyclePeriod", "classEtherCatSettings.html#af2b0eaa4e2d6028da2267acf307ed5b6", null ],
    [ "cycleThreadPriority", "classEtherCatSettings.html#a9028e6c3f3304e2cf4fd39e94aeac3d3", null ],
    [ "readThreadPriority", "classEtherCatSettings.html#a1fd833f4b645760bf6208cd253f0bc0d", null ]
];