var classCopleyNode =
[
    [ "FirmwareUpdate", "classCopleyNode.html#a120053e28abfe39d70e7f2cf2c8e6bc9", null ],
    [ "SerialCmd", "classCopleyNode.html#a77ae4329a32865fa3724a91f7aaf40b1", null ]
];