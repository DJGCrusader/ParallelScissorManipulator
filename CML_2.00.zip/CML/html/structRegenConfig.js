var structRegenConfig =
[
    [ "RegenConfig", "structRegenConfig.html#a1685f7ee9e5ac30a9346d2049fced642", null ],
    [ "contPower", "structRegenConfig.html#ac95a2b7736bc07232543b5a33576ad78", null ],
    [ "model", "structRegenConfig.html#a7d7c8010543de839e94e01bcbad64362", null ],
    [ "peakPower", "structRegenConfig.html#a23732c68e9a49c7143c44df388e215b1", null ],
    [ "peakTime", "structRegenConfig.html#a922f05af4b67ff6c0ab13869ea90d0bb", null ],
    [ "resistance", "structRegenConfig.html#a47475881356ce967ed81d3af72cacabf", null ],
    [ "vOff", "structRegenConfig.html#a9797a44d97b81ba541b61c4e606201bd", null ],
    [ "vOn", "structRegenConfig.html#a6f99a5972879ff46f75a52e815f6dc26", null ]
];