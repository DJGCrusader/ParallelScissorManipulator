var classReceiver =
[
    [ "Receiver", "classReceiver.html#af7d166658670954e71cc15679e11a9f9", null ],
    [ "~Receiver", "classReceiver.html#a68d6e32d96c0c703ea5c19ea254ab399", null ],
    [ "NewFrame", "classReceiver.html#ad250e761b353af6cda60f1b61e229c99", null ]
];