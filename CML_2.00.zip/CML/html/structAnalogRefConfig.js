var structAnalogRefConfig =
[
    [ "AnalogRefConfig", "structAnalogRefConfig.html#a76ae15ad55b2c10a104844e1ca87a684", null ],
    [ "calibration", "structAnalogRefConfig.html#ad5343860a6aa244d73bf4b5971b7d919", null ],
    [ "deadband", "structAnalogRefConfig.html#a6b37597f16d48b7c60a9874d12476e5e", null ],
    [ "offset", "structAnalogRefConfig.html#afedb1b417e0acd2200a0e63a477ecb7a", null ],
    [ "scale", "structAnalogRefConfig.html#afed7c61f24e1cbeab9984fa82008cd56", null ]
];